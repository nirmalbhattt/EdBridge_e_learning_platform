package com.edbridge;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;

@WebServlet("/check01")
public class ServletCheck extends HttpServlet {
	
	
	

}
